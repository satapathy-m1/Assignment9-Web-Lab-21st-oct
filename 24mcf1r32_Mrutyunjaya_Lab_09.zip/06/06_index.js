
function countSubstrings(s, c) {
    let count = 0;

    for (let i = 0; i < s.length; i++) { //(0 to 3)
       if(s[i] === c)
       {
            for (let j = i; j < s.length; j++) {
                if(s[j] === c) count += 1; 
            }
       }
    }
    return count;
}
let s = "adbdadbajrgaaaadjdj";
let c = "a";
console.log("No of substrings:- ",countSubstrings(s, c));  // Output: 6