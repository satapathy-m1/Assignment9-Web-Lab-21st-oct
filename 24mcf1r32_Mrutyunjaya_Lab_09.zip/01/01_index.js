function rowWithMaxOnes(matrix) {
    let maxRowIdx = -1;
    let maxOnesCount = 0;
    let row = 0;
    let col = matrix[0].length - 1; 

    while (row < matrix.length && col >= 0) {
        if (matrix[row][col] === 1) {
            maxRowIdx = row; 
            col--;  
        } else {
            row++;  
        }
    }

    return maxRowIdx;
}

let matrix = [
    [0, 1, 1, 1],
    [0, 0, 1, 1],
    [1, 1, 1, 1],
    [0, 0, 0, 0]
];

console.log("Max row index:- ",rowWithMaxOnes(matrix));  // Output: 2