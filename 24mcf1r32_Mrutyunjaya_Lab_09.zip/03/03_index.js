

function countTriangles(arr) {
    let count = 0;
    arr.sort((a, b) => a - b);

    for (let i = arr.length - 1; i >= 2; i--) {
        let left = 0, right = i - 1;
        while (left < right) {
            if (arr[left] + arr[right] > arr[i]) {
                count += right - left;
                right--;
            } else {
                left++;
            }
        }
    }

    return count;
}

let arr1 = [4, 6, 3, 7];
console.log("No of triangles:- ",countTriangles(arr1));  // Output: 3

let arr2 = [10, 21, 22, 100, 101, 200, 300];
console.log("No of triangles :- ",countTriangles(arr2));  // Output: 6