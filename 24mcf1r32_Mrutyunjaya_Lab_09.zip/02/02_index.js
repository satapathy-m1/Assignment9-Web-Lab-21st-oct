
function comboSumRecursion(index, candidates, target, list, ans){
        if (index === candidates.length) {
            if (target === 0) ans.push([...list]);
            return;
        }

        
        if (candidates[index] <= target) {
            list.push(candidates[index]);
            this.comboSumRecursion(index, candidates, target - candidates[index], list, ans);
            list.pop(); 
        }

        
        this.comboSumRecursion(index + 1, candidates, target, list, ans);
}

function combinationSum(candidates, target){
        const ans = [];
        const list = [];
        const index = 0;
        this.comboSumRecursion(index, candidates, target, list, ans);
        return ans;
    }

let coins1 = [1, 2, 3];
let sum1 = 4;
console.log("No of comobos :-",combinationSum(coins1, sum1).length);  // Output: 4

let coins2 = [2, 5, 3, 6];
let sum2 = 10;
console.log("No of combos:- ",combinationSum(coins2, sum2).length);  // Output: 5