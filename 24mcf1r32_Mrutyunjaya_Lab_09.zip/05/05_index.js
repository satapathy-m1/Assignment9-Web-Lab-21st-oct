
function countAlternatingSubarrays(nums) {
    let count = 0;
    
    for (let i = 0; i < nums.length; i++) {
        let j = i;
        while (j + 1 < nums.length && nums[j] !== nums[j + 1]) {
            j++;
            count++;
        }
    }
    return count + nums.length;  
}
let nums1 = [0, 1, 1, 1];
console.log("No of alternative subarrays "  ,countAlternatingSubarrays(nums1));  // Output: 5

let nums2 = [1, 0, 1, 0, 1,0];
console.log("No of alternative subarrays ",countAlternatingSubarrays(nums2));  // Output: 15