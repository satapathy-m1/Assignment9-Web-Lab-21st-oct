
function kthLargestSum(arr, k) {
    let n = arr.length;
    let sum = [];

   
    for (let i = 0; i < n; i++) {
        let currentSum = 0;
        for (let j = i; j < n; j++) {
            currentSum += arr[j];
            sum.push(currentSum);
        }
    }

    sum.sort((a, b) => b - a);

    return sum[k - 1]; 
}

let arr1 = [20, -5, -1];
let k1 = 3;
console.log("Kth largest element is ",kthLargestSum(arr1, k1));  // Output: 14

let arr2 = [10, -10, 20, -40];
let k2 = 6;
console.log("Kth largest element ",kthLargestSum(arr2, k2));  // Output: -10